ProgressPlatformer
==================
ProgressPlatformer is a game. More specifically, a platformer game. Try it out!

Screenshot
----------

![ProgressPlatformer Screenshot](Achromatic.png "Title screen.")

Usage
-----
If not compiled, this program requires [AutoHotkey](http://www.autohotkey.com/), specifically a version above 1.1.05.00, although the latest version is recommended.

To start, simply open ProgressPlatformer.exe or ProgressPlatformer.ahk, and enjoy the game!

ProgressEngine
--------------
For information about ProgressEngine, see the [ProgressEngine documentation](Documentation/ProgressEngine.md).